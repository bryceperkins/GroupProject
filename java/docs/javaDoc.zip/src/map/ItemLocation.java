package map;

public class ItemLocation {

}
