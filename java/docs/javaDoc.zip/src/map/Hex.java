package map;

public class Hex {
	
	/**
	 * determines if robber is present on a this hex tile
	 * @return true if robber is present on Hex. else false
	 */
	public boolean hasRobber(){return true;}
	
	
	/**
	 * determines if robber can be placed on this hex tile
	 * @return true if robber is not already present or if tile is not a oceanHex. else false
	 */
	public boolean canPlaceRobber(){return true;}
	
}
