package map;

import player.Player;

public abstract class Building {
	
}
