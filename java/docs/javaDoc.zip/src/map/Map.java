package map;

import player.Player;

public class Map {
	
	/**
	 * for each hex that has integer diceRoll as a hexValue, 
	 * the resource of the hex will be given to each player that is on an adjacent hex intersection
	 * @param diceRoll integer that dictates which hex will produce resources this round. Dice roll must be between 2-12
	 */
	public void gatherResources(Integer diceRoll){}
	
	/**
	 * checks if player can place a building a give intersection
	 * @param player input player to check intersection neighbors against. Player must be a valid player
	 * @return true if intersection does not have a settlement as a neighbor AND a neighboring edge must contain a road owned by the inputed player
	 */
	public boolean canBuildSettlement(Player player){return true;}
	
	/**
	 * checks if input player can upgrade a settlement to a city
	 * @param player input player to check if player owns selected settlement. 
	 * @return if intersection contains a settlement that is controlled by the input player, then return true; else fase
	 */
	public boolean canBuildCity(Player player){return true;}
}
