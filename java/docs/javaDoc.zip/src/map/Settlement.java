package map;

public class Settlement extends Building{

}
