package map;

public class Robber {

}
