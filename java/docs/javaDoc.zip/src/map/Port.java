package map;

import player.Player;

public class Port {

	/**
	 * Validates if the user and the bank have the prerequisite amount of resources for a maritime trade. 
	 * @param player Player whose resources are to be validated. Player object must be non-null and a valid player
	 * @param playerResource resources to be traded from player. must be valid resource type
	 * @param bankReturn resource to be provided from bank. Must match port return resource type
	 * @return true if player and bank have necessary resources
	 */
	public boolean canTrade(Player player, ResourceType playerResource, ResourceType bankReturn){return true;}
}
