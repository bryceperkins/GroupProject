package map;

/**
 * Enum for repesenting the direction of edges
 *
 */
public enum Direction {

}
