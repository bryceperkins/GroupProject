package map;

public class City extends Building{

}
